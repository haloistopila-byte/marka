// server.ts
import path3 from "path";
import { fileURLToPath } from "url";

// server/index.ts
import express2 from "express";
import path2 from "path";

// server/config.ts
import path from "path";
try {
  process.loadEnvFile(process.env.ENV_DIR ? path.join(process.env.ENV_DIR, ".env") : void 0);
} catch {
}
var config = {
  port: Number(process.env.PORT) || 3e3,
  // 127.0.0.1 keeps the app on this computer only, with no firewall prompt on Windows
  host: process.env.HOST || "0.0.0.0",
  // Origins allowed to call the API from a browser. Same-origin requests are always allowed.
  allowedOrigins: (process.env.ALLOWED_ORIGINS || "").split(",").map((s) => s.trim()).filter(Boolean),
  // Browser username/password prompt in front of the app. Off unless a password is configured.
  basicAuth: {
    user: process.env.BASIC_AUTH_USER || "admin",
    password: process.env.BASIC_AUTH_PASSWORD || "",
    passwordHash: process.env.BASIC_AUTH_PASSWORD_HASH || "",
    maxFailures: Number(process.env.BASIC_AUTH_MAX_FAILURES) || 10,
    lockoutMinutes: Number(process.env.BASIC_AUTH_LOCKOUT_MINUTES) || 15
  },
  firebaseProjectId: "marka-96250",
  // Must match the list in firestore.rules. Only these accounts may use the calendar routes or be connected to them.
  teamEmails: ["markaselfstudio@gmail.com"],
  google: {
    clientId: process.env.GOOGLE_CLIENT_ID || "",
    clientSecret: process.env.GOOGLE_CLIENT_SECRET || "",
    redirectUri: process.env.GOOGLE_REDIRECT_URI || ""
  }
};

// server/app.ts
import express from "express";

// server/middleware/security.ts
import helmet from "helmet";
import cors from "cors";
import compression from "compression";
import rateLimit from "express-rate-limit";
function applySecurity(app, isProd2) {
  app.set("trust proxy", true);
  app.disable("x-powered-by");
  app.use(
    helmet({
      // A CSP needs testing in production first (Google Fonts, Vite in dev)
      contentSecurityPolicy: false,
      crossOriginEmbedderPolicy: false,
      // Google's login popup reports back to this window; the stricter default cuts that link
      crossOriginOpenerPolicy: { policy: "same-origin-allow-popups" },
      referrerPolicy: { policy: "strict-origin-when-cross-origin" },
      hsts: isProd2 ? { maxAge: 15552e3, includeSubDomains: true } : false
    })
  );
  app.use((_req, res, next) => {
    res.setHeader("Permissions-Policy", "camera=(), microphone=(), geolocation=()");
    res.setHeader("X-Robots-Tag", "noindex, nofollow");
    next();
  });
  app.use(compression());
  const devOrigin = /^https?:\/\/(localhost|127\.0\.0\.1)(:\d+)?$/;
  app.use(
    "/api",
    cors({
      origin(origin, cb) {
        cb(null, !origin || config.allowedOrigins.includes(origin) || !isProd2 && devOrigin.test(origin));
      },
      methods: ["GET", "POST"],
      allowedHeaders: ["Content-Type", "Authorization"],
      maxAge: 600
    })
  );
  app.use("/api", (_req, res, next) => {
    res.setHeader("Cache-Control", "no-store");
    next();
  });
  app.use(
    "/api",
    rateLimit({ windowMs: 6e4, limit: 600, standardHeaders: "draft-7", legacyHeaders: false, validate: { trustProxy: false } })
  );
}
function errorHandler(err, _req, res, _next) {
  const status = Number(err?.status || err?.statusCode) || 500;
  if (status >= 500) console.error("[Server] Unhandled error:", err);
  if (res.headersSent) return;
  res.status(status).json({ success: false, error: status < 500 && err?.message ? err.message : "Terjadi kesalahan pada server." });
}

// server/middleware/basicAuth.ts
import crypto from "crypto";
var sha256 = (value) => crypto.createHash("sha256").update(value).digest();
var sameSecret = (a, b) => crypto.timingSafeEqual(sha256(a), sha256(b));
function matchesHash(password, stored) {
  const [scheme, saltHex, hashHex] = stored.split("$");
  if (scheme !== "scrypt" || !saltHex || !hashHex) return false;
  const expected = Buffer.from(hashHex, "hex");
  const actual = crypto.scryptSync(password, Buffer.from(saltHex, "hex"), expected.length);
  return crypto.timingSafeEqual(actual, expected);
}
function passwordOk(password) {
  const { password: plain, passwordHash } = config.basicAuth;
  return plain ? sameSecret(password, plain) : matchesHash(password, passwordHash);
}
var failures = /* @__PURE__ */ new Map();
var verified = /* @__PURE__ */ new Set();
function lockedOut(ip, now) {
  const entry = failures.get(ip);
  if (entry && entry.resetAt <= now) failures.delete(ip);
  return (failures.get(ip)?.count || 0) >= config.basicAuth.maxFailures;
}
function recordFailure(ip, now) {
  if (failures.size > 5e3) {
    for (const [key, entry2] of failures) if (entry2.resetAt <= now) failures.delete(key);
  }
  const entry = failures.get(ip) || { count: 0, resetAt: now + config.basicAuth.lockoutMinutes * 6e4 };
  entry.count += 1;
  failures.set(ip, entry);
}
function credentialsOk(header) {
  const key = sha256(header).toString("hex");
  if (verified.has(key)) return true;
  if (!header.startsWith("Basic ")) return false;
  const decoded = Buffer.from(header.slice(6), "base64").toString("utf8");
  const split = decoded.indexOf(":");
  if (split < 0) return false;
  const ok = sameSecret(decoded.slice(0, split), config.basicAuth.user) && passwordOk(decoded.slice(split + 1));
  if (ok) verified.add(key);
  return ok;
}
function basicAuthGate(req, res, next) {
  const { password, passwordHash } = config.basicAuth;
  if (!password && !passwordHash || req.path === "/api/health") return next();
  const ip = req.ip || "unknown";
  const now = Date.now();
  if (lockedOut(ip, now)) {
    res.setHeader("Retry-After", String(config.basicAuth.lockoutMinutes * 60));
    return res.status(429).type("text/plain").send("Terlalu banyak percobaan. Coba lagi nanti.");
  }
  if (credentialsOk(req.headers.authorization || "")) return next();
  if (req.headers.authorization) recordFailure(ip, now);
  res.setHeader("WWW-Authenticate", 'Basic realm="Marka Photobooth", charset="UTF-8"');
  res.status(401).type("text/plain").send("Perlu login.");
}

// server/routes/calendar.ts
import { Router } from "express";
import { FieldValue as FieldValue2 } from "firebase-admin/firestore";

// src/features/invoice/figures.ts
function toIso(d) {
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}
function addDays(iso, days) {
  const [y, m, d] = iso.split("-").map(Number);
  return toIso(new Date(y, m - 1, d + days));
}
function formatMoney(n) {
  return "Rp " + Math.round(Number.isFinite(n) ? n : 0).toLocaleString("id-ID");
}
var DEFAULT_EVENT_HOURS = 3;
var eventTitle = (i) => `Marka: ${i.evName || "Event"} (${i.custName || "Customer"})`;
function eventEnd(i) {
  if (i.evEnd && i.evEnd !== i.evStart) return { date: i.evEnd < i.evStart ? addDays(i.evDate, 1) : i.evDate, time: i.evEnd };
  const [h, m] = i.evStart.split(":");
  const hour = Number(h) + DEFAULT_EVENT_HOURS;
  return { date: hour >= 24 ? addDays(i.evDate, 1) : i.evDate, time: `${String(hour % 24).padStart(2, "0")}:${m}` };
}
var invoiceDocId = (num) => encodeURIComponent(num).replace(/\./g, "%2E").replace(/_/g, "%5F");
function calendarEvent(i) {
  if (!i.evDate || i.evStatus === "Batal") return null;
  const timeZone = "Asia/Jakarta";
  const end = i.evStart ? eventEnd(i) : null;
  const items = [...i.packageItems, ...i.addonItems].map((it) => it.desc).filter(Boolean);
  return {
    summary: eventTitle(i),
    description: [
      `Invoice ${i.invNum}`,
      `Customer: ${i.custName}`,
      `HP: ${i.custPhone}`,
      ...items.length ? [`Paket: ${items.join(", ")}`] : [],
      `Pembayaran: ${i.invStatus}, sisa ${formatMoney(i.sisa)}`
    ].join("\n"),
    location: i.evLoc,
    start: end ? { dateTime: `${i.evDate}T${i.evStart}:00`, timeZone } : { date: i.evDate },
    end: end ? { dateTime: `${end.date}T${end.time}:00`, timeZone } : { date: addDays(i.evDate, 1) },
    // The day before, and two hours before setup
    reminders: { useDefault: false, overrides: [{ method: "popup", minutes: 24 * 60 }, { method: "popup", minutes: 120 }] }
  };
}

// server/services/firebaseAdmin.ts
import fs from "fs";
import { cert, getApps, initializeApp } from "firebase-admin/app";
import { getAuth } from "firebase-admin/auth";
import { getFirestore } from "firebase-admin/firestore";
function adminApp() {
  const existing = getApps()[0];
  if (existing) return existing;
  const file = process.env.FIREBASE_SERVICE_ACCOUNT_FILE;
  const raw = process.env.FIREBASE_SERVICE_ACCOUNT || (file && fs.existsSync(file) ? fs.readFileSync(file, "utf8") : "");
  if (!raw) throw new Error("FIREBASE_SERVICE_ACCOUNT_FILE belum diisi di server.");
  let parsed;
  try {
    parsed = JSON.parse(raw);
  } catch {
    throw new Error("Isi service account bukan JSON yang valid.");
  }
  if (parsed.project_id !== config.firebaseProjectId) {
    throw new Error(`Service account harus milik project ${config.firebaseProjectId}.`);
  }
  return initializeApp({ credential: cert(parsed) });
}
var adminDb = () => getFirestore(adminApp());
async function verifyCaller(header) {
  const idToken = header?.startsWith("Bearer ") ? header.slice(7) : "";
  if (!idToken) return null;
  const auth = getAuth(adminApp());
  try {
    return await auth.verifyIdToken(idToken, true);
  } catch {
    return null;
  }
}

// server/middleware/auth.ts
var isTeamEmail = (email, verified2) => verified2 === true && !!email && config.teamEmails.includes(email.toLowerCase());
async function requireTeam(req, res, next) {
  let caller;
  try {
    caller = await verifyCaller(req.headers.authorization);
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
    return;
  }
  if (!caller) {
    res.status(401).json({ success: false, error: "Sesi login tidak valid. Silakan login ulang." });
    return;
  }
  if (!isTeamEmail(caller.email, caller.email_verified)) {
    res.status(403).json({ success: false, error: "Akun ini belum terdaftar sebagai tim Marka." });
    return;
  }
  next();
}

// server/services/calendarApi.ts
var eventIdFor = (invNum) => "marka" + Buffer.from(invNum, "utf8").toString("hex");
async function failure(res) {
  const data = await res.json().catch(() => ({}));
  return new Error(data?.error?.message || `Google Calendar menolak permintaan (HTTP ${res.status}).`);
}
var eventsUrl = (calendarId) => `https://www.googleapis.com/calendar/v3/calendars/${encodeURIComponent(calendarId)}/events`;
async function upsertEvent(token, calendarId, invNum, event) {
  const id = eventIdFor(invNum);
  const url = eventsUrl(calendarId);
  const headers = { Authorization: `Bearer ${token}`, "Content-Type": "application/json" };
  const patch = () => fetch(`${url}/${id}`, {
    method: "PATCH",
    headers,
    body: JSON.stringify({
      ...event,
      // A patch merges, so an event going from all-day to timed must drop the old kind of time.
      start: { date: null, dateTime: null, timeZone: null, ...event.start },
      end: { date: null, dateTime: null, timeZone: null, ...event.end },
      // Brings back an event that was removed when the invoice was cancelled
      status: "confirmed"
    })
  });
  const patched = await patch();
  if (patched.ok) return "Update";
  if (patched.status !== 404) throw await failure(patched);
  const created = await fetch(url, { method: "POST", headers, body: JSON.stringify({ ...event, id }) });
  if (created.ok) return "Tambah";
  if (created.status !== 409) throw await failure(created);
  const retried = await patch();
  if (retried.ok) return "Update";
  throw await failure(retried);
}
async function removeEvent(token, calendarId, invNum) {
  const res = await fetch(`${eventsUrl(calendarId)}/${eventIdFor(invNum)}`, { method: "DELETE", headers: { Authorization: `Bearer ${token}` } });
  if (res.ok) return "Hapus";
  if (res.status === 404 || res.status === 410) return "Lewati";
  throw await failure(res);
}

// server/services/googleCalendarAuth.ts
import crypto2 from "crypto";
import { FieldValue } from "firebase-admin/firestore";
var TOKEN_DOC = "server_private/google_calendar";
var STATUS_DOC = "app/calendar";
var SCOPES = "openid email https://www.googleapis.com/auth/calendar.events";
var STATE_TTL_MS = 10 * 60 * 1e3;
function oauthClient() {
  const { clientId, clientSecret } = config.google;
  if (!clientId || !clientSecret) throw new Error("GOOGLE_CLIENT_ID dan GOOGLE_CLIENT_SECRET belum diisi di server.");
  return { clientId, clientSecret };
}
var redirectUriFor = (origin) => config.google.redirectUri || `${origin}/auth/google/callback`;
var sign = (payload, secret) => crypto2.createHmac("sha256", secret).update(payload).digest("base64url");
function createState(secret, now = Date.now()) {
  const payload = Buffer.from(JSON.stringify({ exp: now + STATE_TTL_MS, nonce: crypto2.randomBytes(12).toString("hex") })).toString("base64url");
  return `${payload}.${sign(payload, secret)}`;
}
function isValidState(state, secret, now = Date.now()) {
  const [payload, signature] = (state ?? "").split(".");
  if (!payload || !signature) return false;
  const expected = Buffer.from(sign(payload, secret));
  const given = Buffer.from(signature);
  if (expected.length !== given.length || !crypto2.timingSafeEqual(expected, given)) return false;
  try {
    return JSON.parse(Buffer.from(payload, "base64url").toString()).exp > now;
  } catch {
    return false;
  }
}
function createConnectUrl(origin) {
  const { clientId, clientSecret } = oauthClient();
  return "https://accounts.google.com/o/oauth2/v2/auth?" + new URLSearchParams({
    client_id: clientId,
    redirect_uri: redirectUriFor(origin),
    response_type: "code",
    scope: SCOPES,
    access_type: "offline",
    prompt: "consent select_account",
    // consent: Google only returns a refresh token on this screen
    login_hint: config.teamEmails[0],
    state: createState(clientSecret)
  });
}
function idTokenClaims(idToken) {
  if (typeof idToken !== "string") return {};
  try {
    return JSON.parse(Buffer.from(idToken.split(".")[1], "base64url").toString("utf8"));
  } catch {
    return {};
  }
}
var revoke = (token) => fetch("https://oauth2.googleapis.com/revoke?token=" + encodeURIComponent(token), { method: "POST" }).catch(() => void 0);
async function completeConnect(origin, code, state) {
  const { clientId, clientSecret } = oauthClient();
  if (!isValidState(state, clientSecret)) return "expired";
  if (!code) return "cancelled";
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ code, client_id: clientId, client_secret: clientSecret, redirect_uri: redirectUriFor(origin), grant_type: "authorization_code" })
  });
  const data = await res.json().catch(() => ({}));
  if (!res.ok || !data.access_token) {
    console.error("[Calendar] Code exchange failed:", data.error, data.error_description);
    return "exchange-failed";
  }
  const claims = idTokenClaims(data.id_token);
  if (!isTeamEmail(claims.email, claims.email_verified)) {
    await revoke(data.refresh_token || data.access_token);
    return "wrong-account";
  }
  if (!data.refresh_token) return "no-refresh-token";
  const stored = {
    refreshToken: data.refresh_token,
    accessToken: data.access_token,
    expiryDate: Date.now() + (data.expires_in || 3600) * 1e3,
    accountEmail: claims.email
  };
  await adminDb().doc(TOKEN_DOC).set(stored);
  await adminDb().doc(STATUS_DOC).set({ connected: true, accountEmail: claims.email }, { merge: true });
  return null;
}
async function forgetConnection() {
  await adminDb().doc(TOKEN_DOC).delete();
  await adminDb().doc(STATUS_DOC).set({ connected: false, accountEmail: FieldValue.delete(), synced: FieldValue.delete() }, { merge: true });
}
async function disconnect() {
  const data = (await adminDb().doc(TOKEN_DOC).get()).data();
  if (data?.refreshToken) await revoke(data.refreshToken);
  await forgetConnection();
}
async function getCalendarAccessToken() {
  const ref = adminDb().doc(TOKEN_DOC);
  const data = (await ref.get()).data();
  if (!data?.refreshToken) return null;
  if (data.accessToken && Date.now() < data.expiryDate - 6e4) return data.accessToken;
  const { clientId, clientSecret } = oauthClient();
  const res = await fetch("https://oauth2.googleapis.com/token", {
    method: "POST",
    headers: { "Content-Type": "application/x-www-form-urlencoded" },
    body: new URLSearchParams({ client_id: clientId, client_secret: clientSecret, refresh_token: data.refreshToken, grant_type: "refresh_token" })
  });
  const body = await res.json().catch(() => ({}));
  if (body.error === "invalid_grant") {
    console.warn("[Calendar] Google rejected the refresh token; connection cleared.");
    await forgetConnection();
    return null;
  }
  if (!res.ok || !body.access_token) throw new Error(`Gagal memperbarui token Google (HTTP ${res.status}).`);
  await ref.set({ accessToken: body.access_token, expiryDate: Date.now() + (body.expires_in || 3600) * 1e3 }, { merge: true });
  return body.access_token;
}

// server/routes/calendar.ts
var MAX_LOG = 20;
var SETTINGS_PATH = "/pengaturan";
var originOf = (req) => `${req.protocol}://${req.host}`;
async function record(invNum, syncedVersion, entry) {
  const ref = adminDb().doc(STATUS_DOC);
  await adminDb().runTransaction(async (tx) => {
    const data = (await tx.get(ref)).data();
    tx.set(
      ref,
      {
        ...syncedVersion !== void 0 && { synced: { [invoiceDocId(invNum)]: syncedVersion ?? FieldValue2.delete() } },
        ...entry && { log: [entry, ...data?.log ?? []].slice(0, MAX_LOG) }
      },
      { merge: true }
    );
  });
}
var router = Router();
var oauthCallbackRouter = Router();
router.post("/connect", requireTeam, (req, res) => {
  try {
    res.json({ success: true, url: createConnectUrl(originOf(req)) });
  } catch (err) {
    res.status(500).json({ success: false, error: err.message });
  }
});
oauthCallbackRouter.get("/auth/google/callback", async (req, res) => {
  const text = (v) => typeof v === "string" ? v : void 0;
  let error;
  try {
    error = await completeConnect(originOf(req), text(req.query.code), text(req.query.state));
  } catch (err) {
    console.error("[Calendar] Connecting failed:", err);
    error = "exchange-failed";
  }
  res.redirect(`${SETTINGS_PATH}?${error ? `calendar_error=${error}` : "calendar_connected=1"}`);
});
router.post("/disconnect", requireTeam, async (_req, res) => {
  await disconnect();
  res.json({ success: true });
});
router.post("/sync", requireTeam, async (req, res) => {
  const invNum = typeof req.body?.invNum === "string" ? req.body.invNum.trim() : "";
  if (!invNum) {
    res.status(400).json({ success: false, error: "Nomor invoice kosong." });
    return;
  }
  const invoice = (await adminDb().doc(`invoices/${invoiceDocId(invNum)}`).get()).data();
  const log = (action, ok, detail) => ({
    at: (/* @__PURE__ */ new Date()).toISOString(),
    invNum,
    custName: invoice?.custName ?? "",
    action,
    ok,
    detail
  });
  const event = invoice ? calendarEvent(invoice) : null;
  try {
    const token = await getCalendarAccessToken();
    if (!token) {
      res.status(409).json({ success: false, error: "Google Calendar belum terhubung." });
      return;
    }
    const saved = (await adminDb().doc("app/settings").get()).data()?.calendarId;
    const calendarId = typeof saved === "string" && saved.trim() || "primary";
    const action = event ? await upsertEvent(token, calendarId, invNum, event) : await removeEvent(token, calendarId, invNum);
    const detail = event ? `${event.summary}` : invoice ? "Event batal atau belum bertanggal." : "Invoice dihapus atau diganti nomornya.";
    await record(invNum, invoice ? invoice.updatedAt : null, action === "Lewati" ? null : log(action, true, detail));
    res.json({ success: true, action });
  } catch (err) {
    const message = err.message;
    console.error(`[Calendar] Sync of ${invNum} failed:`, message);
    await record(invNum, void 0, log(event ? "Update" : "Hapus", false, message)).catch(() => void 0);
    res.status(502).json({ success: false, error: message });
  }
});

// server/routes/health.ts
import { Router as Router2 } from "express";
var router2 = Router2();
router2.get("/", (_req, res) => {
  res.json({ ok: true });
});

// server/app.ts
function createApp({ isProd: isProd2 }) {
  const app = express();
  applySecurity(app, isProd2);
  app.use(basicAuthGate);
  app.get("/robots.txt", (_req, res) => {
    res.type("text/plain").send("User-agent: *\nDisallow: /\n");
  });
  app.use("/api", express.json({ limit: "16kb" }));
  app.use("/api/health", router2);
  app.use("/api/calendar", router);
  app.use(oauthCallbackRouter);
  app.use("/api", (_req, res) => {
    res.status(404).json({ success: false, error: "Endpoint tidak ditemukan." });
  });
  return app;
}

// server/index.ts
async function startServer(rootDir2, isProd2) {
  const app = createApp({ isProd: isProd2 });
  if (!isProd2) {
    const { createServer: createViteServer } = await import("vite");
    const vite = await createViteServer({ server: { middlewareMode: true }, appType: "spa" });
    app.use(vite.middlewares);
  } else {
    const distPath = path2.join(rootDir2, "dist");
    app.use("/assets", express2.static(path2.join(distPath, "assets"), { immutable: true, maxAge: "365d", fallthrough: false }));
    app.use(express2.static(distPath, { index: false, maxAge: "1h" }));
    app.use((_req, res) => {
      res.setHeader("Cache-Control", "no-cache");
      res.sendFile(path2.join(distPath, "index.html"));
    });
  }
  app.use(errorHandler);
  app.listen(config.port, config.host, (err) => {
    if (err) {
      console.error(`[Server] Gagal jalan di port ${config.port}: ${err.message}`);
      process.exit(1);
    }
    console.log(`[Server] Marka Photobooth running on port ${config.port} (${isProd2 ? "production" : "development"})`);
  });
}

// server.ts
var __filename = fileURLToPath(import.meta.url);
var rootDir = path3.dirname(__filename);
var isProd = process.env.NODE_ENV === "production" || __filename.endsWith(".js");
startServer(rootDir, isProd);
